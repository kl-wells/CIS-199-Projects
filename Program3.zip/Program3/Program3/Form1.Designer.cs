﻿namespace Program3
{
    partial class Program3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.stateLbl = new System.Windows.Forms.Label();
            this.productLbl = new System.Windows.Forms.Label();
            this.quantityLbl = new System.Windows.Forms.Label();
            this.initialCostLbl = new System.Windows.Forms.Label();
            this.totalCostLbl = new System.Windows.Forms.Label();
            this.taxLbl = new System.Windows.Forms.Label();
            this.discCostLbl = new System.Windows.Forms.Label();
            this.stateComboBox = new System.Windows.Forms.ComboBox();
            this.productTbox = new System.Windows.Forms.TextBox();
            this.quantityTbox = new System.Windows.Forms.TextBox();
            this.calcButton = new System.Windows.Forms.Button();
            this.initialCostOutput = new System.Windows.Forms.Label();
            this.taxOutput = new System.Windows.Forms.Label();
            this.totalPriceOutput = new System.Windows.Forms.Label();
            this.discountCostOutput = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // stateLbl
            // 
            this.stateLbl.AutoSize = true;
            this.stateLbl.Location = new System.Drawing.Point(203, 113);
            this.stateLbl.Name = "stateLbl";
            this.stateLbl.Size = new System.Drawing.Size(100, 37);
            this.stateLbl.TabIndex = 0;
            this.stateLbl.Text = "State:";
            this.stateLbl.Click += new System.EventHandler(this.label1_Click);
            // 
            // productLbl
            // 
            this.productLbl.AutoSize = true;
            this.productLbl.Location = new System.Drawing.Point(166, 187);
            this.productLbl.Name = "productLbl";
            this.productLbl.Size = new System.Drawing.Size(137, 37);
            this.productLbl.TabIndex = 1;
            this.productLbl.Text = "Product:";
            // 
            // quantityLbl
            // 
            this.quantityLbl.AutoSize = true;
            this.quantityLbl.Location = new System.Drawing.Point(158, 264);
            this.quantityLbl.Name = "quantityLbl";
            this.quantityLbl.Size = new System.Drawing.Size(145, 37);
            this.quantityLbl.TabIndex = 2;
            this.quantityLbl.Text = "Quantity:";
            // 
            // initialCostLbl
            // 
            this.initialCostLbl.AutoSize = true;
            this.initialCostLbl.Location = new System.Drawing.Point(128, 477);
            this.initialCostLbl.Name = "initialCostLbl";
            this.initialCostLbl.Size = new System.Drawing.Size(175, 37);
            this.initialCostLbl.TabIndex = 3;
            this.initialCostLbl.Text = "Initial Cost:";
            // 
            // totalCostLbl
            // 
            this.totalCostLbl.AutoSize = true;
            this.totalCostLbl.Location = new System.Drawing.Point(124, 718);
            this.totalCostLbl.Name = "totalCostLbl";
            this.totalCostLbl.Size = new System.Drawing.Size(179, 37);
            this.totalCostLbl.TabIndex = 4;
            this.totalCostLbl.Text = "Total Price:";
            // 
            // taxLbl
            // 
            this.taxLbl.AutoSize = true;
            this.taxLbl.Location = new System.Drawing.Point(224, 638);
            this.taxLbl.Name = "taxLbl";
            this.taxLbl.Size = new System.Drawing.Size(79, 37);
            this.taxLbl.TabIndex = 5;
            this.taxLbl.Text = "Tax:";
            // 
            // discCostLbl
            // 
            this.discCostLbl.AutoSize = true;
            this.discCostLbl.Location = new System.Drawing.Point(42, 562);
            this.discCostLbl.Name = "discCostLbl";
            this.discCostLbl.Size = new System.Drawing.Size(261, 37);
            this.discCostLbl.TabIndex = 6;
            this.discCostLbl.Text = "Discounted Cost:";
            // 
            // stateComboBox
            // 
            this.stateComboBox.FormattingEnabled = true;
            this.stateComboBox.Items.AddRange(new object[] {
            "KY",
            "OH",
            "IN",
            "IL"});
            this.stateComboBox.Location = new System.Drawing.Point(367, 110);
            this.stateComboBox.Name = "stateComboBox";
            this.stateComboBox.Size = new System.Drawing.Size(247, 45);
            this.stateComboBox.TabIndex = 7;
            // 
            // productTbox
            // 
            this.productTbox.Location = new System.Drawing.Point(367, 184);
            this.productTbox.Name = "productTbox";
            this.productTbox.Size = new System.Drawing.Size(247, 44);
            this.productTbox.TabIndex = 8;
            // 
            // quantityTbox
            // 
            this.quantityTbox.Location = new System.Drawing.Point(367, 261);
            this.quantityTbox.Name = "quantityTbox";
            this.quantityTbox.Size = new System.Drawing.Size(247, 44);
            this.quantityTbox.TabIndex = 9;
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(292, 360);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(202, 51);
            this.calcButton.TabIndex = 10;
            this.calcButton.Text = "Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // initialCostOutput
            // 
            this.initialCostOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.initialCostOutput.Location = new System.Drawing.Point(367, 476);
            this.initialCostOutput.Name = "initialCostOutput";
            this.initialCostOutput.Size = new System.Drawing.Size(247, 44);
            this.initialCostOutput.TabIndex = 11;
            // 
            // taxOutput
            // 
            this.taxOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.taxOutput.Location = new System.Drawing.Point(367, 637);
            this.taxOutput.Name = "taxOutput";
            this.taxOutput.Size = new System.Drawing.Size(247, 44);
            this.taxOutput.TabIndex = 12;
            // 
            // totalPriceOutput
            // 
            this.totalPriceOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalPriceOutput.Location = new System.Drawing.Point(367, 717);
            this.totalPriceOutput.Name = "totalPriceOutput";
            this.totalPriceOutput.Size = new System.Drawing.Size(247, 44);
            this.totalPriceOutput.TabIndex = 13;
            // 
            // discountCostOutput
            // 
            this.discountCostOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.discountCostOutput.Location = new System.Drawing.Point(367, 561);
            this.discountCostOutput.Name = "discountCostOutput";
            this.discountCostOutput.Size = new System.Drawing.Size(247, 44);
            this.discountCostOutput.TabIndex = 14;
            // 
            // Program3
            // 
            this.AcceptButton = this.calcButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 37F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(802, 882);
            this.Controls.Add(this.discountCostOutput);
            this.Controls.Add(this.totalPriceOutput);
            this.Controls.Add(this.taxOutput);
            this.Controls.Add(this.initialCostOutput);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.quantityTbox);
            this.Controls.Add(this.productTbox);
            this.Controls.Add(this.stateComboBox);
            this.Controls.Add(this.discCostLbl);
            this.Controls.Add(this.taxLbl);
            this.Controls.Add(this.totalCostLbl);
            this.Controls.Add(this.initialCostLbl);
            this.Controls.Add(this.quantityLbl);
            this.Controls.Add(this.productLbl);
            this.Controls.Add(this.stateLbl);
            this.Name = "Program3";
            this.Text = "Sales Co Cost Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label stateLbl;
        private System.Windows.Forms.Label productLbl;
        private System.Windows.Forms.Label quantityLbl;
        private System.Windows.Forms.Label initialCostLbl;
        private System.Windows.Forms.Label totalCostLbl;
        private System.Windows.Forms.Label taxLbl;
        private System.Windows.Forms.Label discCostLbl;
        private System.Windows.Forms.ComboBox stateComboBox;
        private System.Windows.Forms.TextBox productTbox;
        private System.Windows.Forms.TextBox quantityTbox;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.Label initialCostOutput;
        private System.Windows.Forms.Label taxOutput;
        private System.Windows.Forms.Label totalPriceOutput;
        private System.Windows.Forms.Label discountCostOutput;
    }
}

