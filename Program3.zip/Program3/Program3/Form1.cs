﻿//Program 3
//CIS 199-01
//Grading ID: R2553
//Due: 11-5-2020
//This program calculates the price of products depending on the state tax, any discount, and the
//cost per unit then outputs it to a label on the form.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program3
{
    public partial class Program3 : Form
    {
        public Program3()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        public const int MINPRODUCTNUM = 1001;      //Minimum product number allowed

        public const int MAXPRODUCTNUM = 1007;      //Maximum product number allowed

        public int[] productNum = { 1001, 1002, 1003, 1004, 1005, 1006, 1007 }; //list of product numbers

        public double[] costPerUnit = { 7.87, 9.51, 10.73, 9.99, 11.99, 5.00, 4.58 }; //prices that correspond with products

        public string[] stateOptions = { "KY", "OH", "IN", "IL" };  //state options

        public double[] taxes = { .06, .0717, .07, .0874 };     //tax per state

        public int[] minQuantity = { 0, 5, 10, 20 };        //minimum product quantity for discounts

        public double[] quantityDiscount = { 1.0, 0.95, 0.90, 0.86 }; //discount per quantity

        private void calcButton_Click(object sender, EventArgs e)
        {
            double totalPrice;          //total price
            double discount = 0;        //discount from initial
            double initialCost;         //initial cost
            double discountCost;        //discounted cost
            double taxCost;             //cost of tax
            double product;             //product number
            double tax = 0;             //tax percentage
            double unitPrice = 0;       //unit price
            bool stateFound = false;    //is the state an option
            bool productFound = false;  //is this a valid product number
            bool qtyFound = false;      //is this a valid quantity
            int MIN = 0;                //minimum number allowed
            int quantity;               //quantity entered
            string state;               //state selected

            //gets the input from the user for quantity and determines if it is valid
            quantity = int.Parse(quantityTbox.Text);
            if (quantity <= MIN)
                MessageBox.Show("Please enter a valid quantity");

            //gets the user's input for the state and determines if it is valid
            if (stateComboBox.SelectedIndex >= MIN)
            {
                stateFound = true;
            }
            else
               MessageBox.Show("Please select a state");

            state = stateComboBox.Text;

            //determines the state and the tax that goes with it
            for (int i = 0; i <= stateOptions.Length - 1; ++i)
            {
                if (state == stateOptions[i])
                    tax = taxes[i];
            }

            //tries parsing the product number
            double.TryParse(productTbox.Text, out product);

            //determines if this is a valid product number
            if (product >= MINPRODUCTNUM && product <= MAXPRODUCTNUM)
                productFound = true;
            else
                MessageBox.Show("Please enter a valid product number");

            //determines the price per unit from the product
            for (int i = 0; i < productNum.Length; ++i)
            {
                if (productNum[i] == product)
                {
                    unitPrice = costPerUnit[i];
                }
            }

            //index for quantity
            int index = minQuantity.Length - 1;

            //determines if the quantity is valid and assigns it a discount
            while (index >= 0 && !qtyFound)
            {
                if (quantity >= minQuantity[index])
                {
                    qtyFound = true;
                }
                else
                    --index;
            }
            if(qtyFound == true)
                discount = quantityDiscount[index];

            //detemines the initial cost and outputs it to the label
            initialCost = quantity * unitPrice;
            initialCostOutput.Text = ($"{initialCost:C}");

            //determines the cost of tax and outputs it to the label
            taxCost = tax * initialCost;
            taxOutput.Text = ($"{taxCost:C}");

            //determines the discount cost and outputs it to the label
            discountCost = initialCost * discount;
            discountCostOutput.Text = ($"{discountCost:C}");

            //determines the overall price and outputs it to the label
            totalPrice = discountCost + taxCost;
            totalPriceOutput.Text = ($"{totalPrice:C}");
            
        }
    }
}
