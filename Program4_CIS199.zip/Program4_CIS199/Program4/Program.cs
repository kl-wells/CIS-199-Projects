﻿//Program 4
//Grading ID: R2553
//CIS 199-01
//Due: 12-01-2020
//This program executes a series of service orders along with it's 7 properties to the Console.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Program4;


    class Program
    {
        static void Main(string[] args)
        {
            //array for service orders
            ServiceOrder[] serviceOrders = new ServiceOrder[6];
            serviceOrders[0] = new ServiceOrder(41051, "A5833", 1419279488, true, "Caleb Kline", 45);       
            serviceOrders[1] = new ServiceOrder(41005, "B7534", 1895950393, false, "Abigail Jones", 120);
            serviceOrders[2] = new ServiceOrder(40208, "B1298", 1298472610, true, "Katelyn Moore", 75);
            serviceOrders[3] = new ServiceOrder(40829, "A2985", 1192119382, true, "Harry Potter", 150);
            serviceOrders[4] = new ServiceOrder(39109, "A2938", 1234123412, false, "Eli Brown", 30);
            serviceOrders[5] = new ServiceOrder(41042, "B3910", 1987654321, true, "Karby King", 60);

            //replacements in the array for each item
            serviceOrders[0].ServiceLocationZipCode = 12345;
            serviceOrders[1].ModelNumber = "A4921";
            serviceOrders[2].SerialNumber = 1111111111;
            serviceOrders[3].WarrantyStatus = false;
            serviceOrders[4].TechnicianName = "Michelle Long";
            serviceOrders[5].AppointmentLength = 60;

            DisplayServiceOrder(serviceOrders);
        }
        //precondition: Service order objects are passed
        //postcondition: Service orders are displayed to the console
        public static void DisplayServiceOrder(ServiceOrder[] serviceOrders)
            
        {
            //generates the output
            for (int i = 0; i <= serviceOrders.Length - 1; i++)
            { 
                Console.Write($"{serviceOrders[i].ToString()}");
            Console.WriteLine($"{serviceOrders[i].CalcCost()}");
            }
        }
    }


