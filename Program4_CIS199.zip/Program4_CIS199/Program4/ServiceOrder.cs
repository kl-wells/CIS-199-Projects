﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Program4
{
    class ServiceOrder
    {
        //backing fields
        private int serviceLocationZipCode; //creates a backing field for the zip code
        private string modelNumber;         //creates a backing field for the model number
        private int serialNumber;           //creates a backing field for the serial number
        private int appointmentLength;      //creates a backing field for the appt length
        private string techName;            //creates a backing field for the technicians name
        private bool warrantyStatus;        //creates a backing field for the warranty status

        //default values
        private const int defaultZipCode = 40204;               //default value for zip code
        private const string defaultTechName = "John Smith";    //default value for technicians name
        private const string defaultModelNumber = "A1234";      //default value for model number
        private const string defaultSerialNumber = "C123456789";//default value for serial number
        private const int defaultAppointmentLength = 30;        //default value for appointment length

        //Magic numbers
        private const double feePerMinsNoWarranty = 1.5;    //fee per minute with no warranty
        private const int flatFeeNoWarranty = 25;           //base fee for no warranty
        private const int minsToHours = 60;                 //conversion for min to hours
        private const double costWithWarranty = 20;         //flat fee with warranty
        private const int minZipCode = 00000;               //min zip code allowed
        private const int maxZipCode = 99999;               //maximum number for zip code
        private const int minApptTime = 15;                 //minimum time for appointment
        private const int maxApptTime = 180;                //maximum time for appointment
        private const int minSerialNumLength = 10;          //minimum serial number length
        private const int minModelNumLength = 5;            //minimum model number length

        //Preconditions: Values for each argument are acceptable in the relevant property
        //Postconditions: Objects for each are created and passed
        public ServiceOrder(int serviceLocationZipCode, string modelNumber, int serialNumber,
            bool warrantyStatus, string techName, int appointmentLength)
        {
            ServiceLocationZipCode = serviceLocationZipCode;
            ModelNumber = modelNumber;
            SerialNumber = serialNumber;
            TechnicianName = techName;
            AppointmentLength = appointmentLength;
            WarrantyStatus = warrantyStatus;
        }

        //precondition: Zip is between 00000 and 99999
        //postcondition: Zip code is returned
        public int ServiceLocationZipCode
        {
            get
            {
                return serviceLocationZipCode;
            }
            set
            {
                if (value >= minZipCode && value <= maxZipCode)
                    serviceLocationZipCode = value;
                else
                    serviceLocationZipCode = defaultZipCode;
            }
        }

        //precondition: Number must be a 5 character string
        //postcondition: returns the model number
        public string ModelNumber
        {
            get
            {
                return modelNumber;
            }
            set
            {
                if (value.Length == minModelNumLength)
                    modelNumber = value;
                else
                    modelNumber = defaultModelNumber;
            }
        }

        //precondition: serial mumber must be 10 numbers long
        //postcondition: returns the serial number
        public int SerialNumber
        {
            get
            {
                return serialNumber;
            }
            set
            {
                if (value.ToString().Length == minSerialNumLength)
                    serialNumber = value;
                else
                    serialNumber = int.Parse(defaultSerialNumber);
            }
        }

        //precondition: Name cannot be blank
        //postcondition: Returns the technician's name
        public string TechnicianName
        {
            get
            {
                return techName;
            }
            set
            {
                if (String.IsNullOrWhiteSpace(value))
                    techName = value;
                else
                    techName = defaultTechName;
            }
        }

        //precondition: Appointment length must be between 15 and 180 minutes.
        //postcondition: Returns the appointment length value
        public int AppointmentLength
        {
            get
            {
                return appointmentLength;
            }
            set
            {
                if (value >= minApptTime && value <= maxApptTime)
                    appointmentLength = value;
                else
                    appointmentLength = defaultAppointmentLength;
            }
        }

        //precondition: Value must be true or false
        //postcondition: returns value in warranty status
        public bool WarrantyStatus
        {
            get
            {
                return warrantyStatus;
            }
            set
            {
                warrantyStatus = value;
            }
        }

        public double AppointmentHours  //converts the length to hours
        {
            get
            {
                return appointmentLength / minsToHours;
            }
        }

        //Determines the cost with and without warranty
        public double CalcCost()
        {
            double finalCost;   //generates the final cost
            if (warrantyStatus == true)
                finalCost = costWithWarranty;
            else
                finalCost = flatFeeNoWarranty + (feePerMinsNoWarranty * appointmentLength);
            return finalCost;
        }

        //precondition: Object instantiated
        //postcondition: String for object returned
        public override string ToString()
        {
            String objectString = $"Service Location Zip Code: {ServiceLocationZipCode}" +
                $"Model Number: {ModelNumber}" + $"Serial Number: {SerialNumber}" +
                $"Appointment Length: {AppointmentLength:F2}" + $"Appointment Hours: {AppointmentHours}" +
                $"Technician Name: {TechnicianName}" + $"Warranty Coverage: {WarrantyStatus}";
            return objectString;
        }
    }
}


